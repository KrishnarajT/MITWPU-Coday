package com.nice.avishkar;

import java.io.IOException;
import java.nio.file.Path;

public class InventoryPredictorImpl implements InventoryPredictor {
    @Override
    public PredictedWarehouseInfo predictWarehouseCapacityWithProductDetails(ResourceInfo resourceInfo) throws IOException {
        //Code here

        return null;
    }
}
